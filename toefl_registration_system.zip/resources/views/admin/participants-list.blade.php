@extends('layouts.app')

@section('title', 'Daftar Peserta')

@section('content')
<div class="row">
    <div class="col-md-12">
        <h1>Peserta untuk {{ $schedule->room }} - {{ $schedule->date->format('d M Y') }}</h1>
        <a href="{{ route('admin.dashboard') }}" class="btn btn-secondary mb-3">Kembali ke Dashboard</a>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h5 class="mb-4">Detail Jadwal</h5>
                <div class="table-responsive">
                    <table class="table table-borderless mb-0">
                        <tbody>
                            <tr>
                                <td class="fw-bold" style="width: 20%;">Tanggal</td>
                                <td style="width: 5%;">:</td>
                                <td>{{ $schedule->date->format('d M Y') }}</td>
                            </tr>
                            <tr>
                                <td class="fw-bold" style="width: 20%;">Ruangan</td>
                                <td style="width: 5%;">:</td>
                                <td>{{ $schedule->room }}</td>
                            </tr>
                            <tr>
                                <td class="fw-bold" style="width: 20%;">Kategori</td>
                                <td style="width: 5%;">:</td>
                                <td>{{ $schedule->category }}</td>
                            </tr>
                            <tr>
                                <td class="fw-bold" style="width: 20%;">Kapasitas</td>
                                <td style="width: 5%;">:</td>
                                <td>{{ $schedule->used_capacity }} / {{ $schedule->capacity }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Form Pencarian NIM -->
<div class="row mb-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Cari Peserta berdasarkan NIM</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="{{ route('admin.participants.list', $schedule->id) }}">
                    <div class="row">
                        <div class="col-md-8">
                            <input type="text"
                                   name="search_nim"
                                   class="form-control"
                                   placeholder="Masukkan NIM peserta..."
                                   value="{{ request('search_nim') }}">
                        </div>
                        <div class="col-md-4">
                            <div class="d-grid gap-2 d-md-flex">
                                <button type="submit" class="btn btn-primary flex-fill">
                                    <i class="fas fa-search"></i> Cari
                                </button>
                                <a href="{{ route('admin.participants.list', $schedule->id) }}" class="btn btn-secondary flex-fill">
                                    <i class="fas fa-times"></i> Reset
                                </a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Peserta Terdaftar</h3>
            @if(Auth::user()->isAdmin())
            <div class="group-btn" role="group">
                <a href="{{ route('admin.schedule.participants.export', $schedule->id) }}" class="btn btn-success">
                    <i class="fas fa-download"></i> Download Seluruh Peserta
                </a>
                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteAllModal">
                    <i class="fas fa-trash-alt"></i> Hapus Seluruh Peserta
                </button>
            </div>
            @else
            <a href="{{ route('admin.schedule.participants.export', $schedule->id) }}" class="btn btn-success">
                <i class="fas fa-download"></i> Download Seluruh Peserta
            </a>
            @endif
        </div>

        <!-- Delete All Participants Modal -->
        <div class="modal fade" id="deleteAllModal" tabindex="-1" aria-labelledby="deleteAllModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteAllModalLabel">Konfirmasi Penghapusan Seluruh Peserta</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Anda akan menghapus seluruh peserta pada jadwal:</p>
                        <p><strong>Ruangan:</strong> {{ $schedule->room }}<br>
                        <strong>Tanggal:</strong> {{ $schedule->date->format('d M Y') }}</p>
                        <p><strong>Jumlah Peserta:</strong> {{ $totalParticipants }}</p>
                        <p class="text-danger">Tindakan ini tidak dapat dibatalkan. Semua peserta akan dihapus secara permanen.</p>
                        <p>Mohon ketik <strong>"HAPUS {{ $totalParticipants }} PESERTA"</strong> untuk mengonfirmasi penghapusan:</p>
                        <input type="text" class="form-control" id="confirmDeleteAll" placeholder="Ketik perintah penghapusan">
                        <div id="confirmDeleteAllError" class="text-danger mt-1" style="display:none;">Perintah penghapusan tidak sesuai</div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <form action="{{ route('admin.schedule.clear-participants', $schedule->id) }}" method="POST" class="d-inline" id="clearAllParticipantsForm" style="display:none;">
                            @csrf
                            <button type="submit" class="btn btn-danger" id="deleteAllConfirmedBtn">Konfirmasi Hapus Semua</button>
                        </form>
                        <button type="button" class="btn btn-danger" id="verifyDeleteAllBtn">Verifikasi dan Hapus</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
        document.getElementById('verifyDeleteAllBtn').addEventListener('click', function() {
            const expectedText = "HAPUS {{ $totalParticipants }} PESERTA";
            const inputText = document.getElementById('confirmDeleteAll').value;
            const errorElement = document.getElementById('confirmDeleteAllError');
            const confirmForm = document.getElementById('clearAllParticipantsForm');
            const confirmBtn = document.getElementById('deleteAllConfirmedBtn');

            if (inputText.trim() === expectedText) {
                errorElement.style.display = 'none';
                confirmForm.style.display = 'inline';
                confirmBtn.style.display = 'inline-block';
                // Disable the verify button to prevent double action
                this.disabled = true;
            } else {
                errorElement.style.display = 'block';
                confirmForm.style.display = 'none';
                confirmBtn.style.display = 'none';
            }
        });

        // Reset modal when closed
        document.getElementById('deleteAllModal').addEventListener('hidden.bs.modal', function() {
            document.getElementById('confirmDeleteAll').value = '';
            document.getElementById('confirmDeleteAllError').style.display = 'none';
            document.getElementById('clearAllParticipantsForm').style.display = 'none';
            document.getElementById('verifyDeleteAllBtn').disabled = false;
        });
        </script>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Nomor Kursi</th>
                        <th>NIM</th>
                        <th>Nama</th>
                        <th>Status Verifikasi</th>
                        <th>Kehadiran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($participants as $participant)
                    <tr>
                        <td>{{ $participant->effective_seat_number }}</td>
                        <td>{{ $participant->nim }}</td>
                        <td>{{ $participant->name }}</td>
                        <td>{{ $participant->studyProgram->name }} {{ $participant->studyProgram->level }}</td>
                        <td>
                            <span class="badge bg-{{ $participant->status === 'confirmed' ? 'success' : ($participant->status === 'pending' ? 'warning' : ($participant->status === 'rejected' ? 'danger' : 'secondary')) }}">
                                {{ $participant->status === 'confirmed' ? 'Terkonfirmasi' : ($participant->status === 'pending' ? 'Tertunda' : ($participant->status === 'rejected' ? 'Ditolak' : 'Dibatalkan')) }}
                            </span>
                        </td>
                        <td>
                            @if($participant->attendance === 'present')
                                <span class="badge bg-success">Hadir</span>
                            @elseif($participant->attendance === 'absent')
                                <span class="badge bg-danger">Tidak Hadir</span>
                            @elseif($participant->attendance === 'permission')
                                <span class="badge bg-warning text-dark">Izin</span>
                            @else
                                <span class="badge bg-secondary">-</span>
                            @endif
                            <button type="button" 
                                    class="btn btn-sm btn-link p-0 ms-1" 
                                    onclick="openAttendanceModal({{ $participant->id }}, '{{ $participant->name }}', '{{ $participant->attendance }}')"
                                    {{ $participant->passed ? 'disabled title="Tidak dapat mengubah kehadiran peserta yang sudah Lulus"' : '' }}>
                                <i class="fas fa-edit {{ $participant->passed ? 'text-muted' : '' }}"></i>
                            </button>
                        </td>
                        <td>
                            <a href="{{ route('admin.participant.details', $participant->id) }}" class="btn btn-info btn-sm me-1">Lihat Detail</a>
                            @if(Auth::user()->isOperator())
                            <button type="button" 
                                    class="btn btn-warning btn-sm me-1" 
                                    onclick="openResetPasswordModal({{ $participant->id }}, '{{ $participant->name }}', '{{ $participant->username }}')">
                                <i class="fas fa-key"></i> Reset
                            </button>
                            <form action="{{ route('admin.participant.delete', $participant->id) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus peserta ini?')">Hapus</button>
                            </form>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        @if($searchNim)
                            <td colspan="7" class="text-center">Tidak ditemukan peserta dengan NIM: {{ $searchNim }}</td>
                        @else
                            <td colspan="7" class="text-center">Tidak ada peserta terdaftar untuk jadwal ini</td>
                        @endif
                    </tr>
                    @endforelse
                </tbody>
            </table>
            @if($participants->hasPages())
                <div class="d-flex justify-content-center">
                    {{ $participants->appends(['search_nim' => $searchNim])->links() }}
                </div>
            @endif
        </div>
    </div>
</div>

<!-- Attendance Modal -->
<div class="modal fade" id="attendanceModal" tabindex="-1" aria-labelledby="attendanceModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="attendanceModalLabel">Set Kehadiran - <span id="attendanceParticipantName"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="attendanceForm" action="" method="POST">
                    @csrf
                    @method('PUT')
                    
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-outline-success p-3 text-start" onclick="setAttendance('present')">
                            <i class="fas fa-check-circle me-2"></i> <strong>Hadir</strong>
                            <div class="small text-muted ms-4">Peserta hadir dan mengikuti ujian.</div>
                        </button>
                        
                        <button type="button" class="btn btn-outline-danger p-3 text-start" onclick="setAttendance('absent')">
                            <i class="fas fa-times-circle me-2"></i> <strong>Tidak Hadir</strong>
                            <div class="small text-muted ms-4">Peserta tidak hadir (Otomatis Gagal).</div>
                        </button>
                        
                        <button type="button" class="btn btn-outline-warning p-3 text-start" onclick="setAttendance('permission')">
                            <i class="fas fa-clock me-2"></i> <strong>Izin (Reschedule)</strong>
                            <div class="small text-muted ms-4">Peserta minta pindah jadwal.</div>
                        </button>
                    </div>
                    
                    <input type="hidden" name="attendance" id="attendanceInput">
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Reschedule Modal -->
<div class="modal fade" id="rescheduleModal" tabindex="-1" aria-labelledby="rescheduleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="rescheduleModalLabel">Pilih Jadwal Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Silakan pilih jadwal tes pengganti untuk peserta ini:</p>
                <form id="rescheduleForm" action="" method="POST">
                    @csrf
                    @method('PUT')
                    
                    <div class="mb-3">
                        <label for="new_schedule_id" class="form-label">Jadwal Tersedia</label>
                        <select class="form-select" name="new_schedule_id" id="new_schedule_id" required>
                            <option value="">-- Pilih Jadwal --</option>
                            @php
                                // Fetch available schedules logic should ideally be passed from controller, 
                                // but for now we can use a direct query or View Composer. 
                                // TO AVOID N+1 or logic in view, a better way is to pass it from controller.
                                // For this prompt, I'll assume we can pass $availableSchedules from controller or fetch here for simplicity.
                                $availableSchedules = \App\Models\Schedule::where('status', 'available')
                                    ->where('id', '!=', $schedule->id)
                                    ->whereColumn('used_capacity', '<', 'capacity')
                                    ->where('date', '>=', now())
                                    ->orderBy('date')
                                    ->get();
                            @endphp
                            @foreach($availableSchedules as $s)
                                <option value="{{ $s->id }}">
                                    {{ $s->date->format('d M Y') }} - {{ $s->room }} ({{ $s->used_capacity }}/{{ $s->capacity }})
                                </option>
                            @endforeach
                        </select>
                        @if($availableSchedules->isEmpty())
                            <div class="text-danger mt-2 small">
                                <i class="fas fa-exclamation-circle"></i> Tidak ada jadwal lain yang tersedia. Silakan buat jadwal baru terlebih dahulu.
                            </div>
                        @endif
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-primary" onclick="submitReschedule()">Pindahkan Peserta</button>
            </div>
        </div>
    </div>
</div>

<script>
    let currentParticipantId = null;

    function openAttendanceModal(id, name, currentStatus) {
        currentParticipantId = id;
        document.getElementById('attendanceParticipantName').textContent = name;
        
        // Reset buttons style if you want to highlight current status
        // ...
        
        const modal = new bootstrap.Modal(document.getElementById('attendanceModal'));
        modal.show();
    }

    function setAttendance(status) {
        const modalEl = document.getElementById('attendanceModal');
        const modal = bootstrap.Modal.getInstance(modalEl);
        
        if (status === 'permission') {
            // Close attendance modal and open reschedule modal
            modal.hide();
            
            // Set form action for reschedule
            const form = document.getElementById('rescheduleForm');
            form.action = `/admin/participant/${currentParticipantId}/reschedule`;
            
            // Mark attendance as permission first via AJAX, then show modal? 
            // Better flow: Just show modal. The reschedule action implies permission.
            // BUT requirement: "jika peserta izin admin memindahkan jadwal". 
            // So let's open reschedule modal.
            
            const rescheduleModal = new bootstrap.Modal(document.getElementById('rescheduleModal'));
            rescheduleModal.show();
            
            // We should also update attendance status to 'permission' in background or as part of reschedule?
            // Let's update attendance first to permission via AJAX, then reschedule?
            // Or just Reschedule Controller handles everything? 
            // Controller rescheduleParticipant updates attendance to null/reset.
            // So we don't strictly need to set 'permission' in DB if we move them immediately.
            // However, the user might want to just mark as permission and reschedule LATER?
            // "jika peserta tidak hadir berdasarkan jadwal tes maka peserta gagal" -> handled by absent
            // "jika peserta izin admin memindahkan jadwal" -> handled here.
            
            return;
        }

        // For Present/Absent
        const form = document.getElementById('attendanceForm');
        form.action = `/admin/participant/${currentParticipantId}/attendance`;
        document.getElementById('attendanceInput').value = status;
        
        // Submit
        form.submit();
    }

    function submitReschedule() {
        document.getElementById('rescheduleForm').submit();
    }

    function openResetPasswordModal(id, name, username) {
        document.getElementById('resetParticipantId').value = id;
        document.getElementById('resetParticipantName').textContent = name;
        document.getElementById('resetParticipantUsername').textContent = username;
        
        const modal = new bootstrap.Modal(document.getElementById('resetPasswordListModal'));
        modal.show();
    }
</script>

<!-- Reset Password Modal (List) -->
<div class="modal fade" id="resetPasswordListModal" tabindex="-1" aria-labelledby="resetPasswordListModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-warning text-dark rounded-top-4">
                <h5 class="modal-title fw-bold" id="resetPasswordListModalLabel">Reset Kata Sandi Peserta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ route('admin.reset.participant.password') }}" method="POST">
                @csrf
                @method('PUT')
                <div class="modal-body">
                    <input type="hidden" name="participant_id" id="resetParticipantId">
                    <div class="mb-4">
                        <label class="form-label fw-bold text-muted">Peserta:</label>
                        <div class="p-3 bg-light rounded-3">
                            <div class="fw-bold" id="resetParticipantName"></div>
                            <div class="small text-muted">Username: <span id="resetParticipantUsername"></span></div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="new_password" class="form-label fw-bold">Kata Sandi Baru</label>
                        <input type="password" class="form-control rounded-3" id="new_password" name="new_password" required minlength="12">
                        <small class="text-muted">Min. 12 karakter, huruf besar, kecil, angka, spesial.</small>
                    </div>
                    <div class="mb-3">
                        <label for="new_password_confirmation" class="form-label fw-bold">Konfirmasi Kata Sandi Baru</label>
                        <input type="password" class="form-control rounded-3" id="new_password_confirmation" name="new_password_confirmation" required>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-warning rounded-pill px-4 fw-bold shadow-sm">Reset Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection