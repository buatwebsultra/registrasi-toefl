<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasColumn('participants', 'attendance')) {
            Schema::table('participants', function (Blueprint $table) {
                // adding enum column for attendance: present, absent, permission
                $table->enum('attendance', ['present', 'absent', 'permission'])->nullable()->after('status');
                $table->timestamp('attendance_marked_at')->nullable()->after('attendance');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('participants', function (Blueprint $table) {
            $table->dropColumn(['attendance', 'attendance_marked_at']);
        });
    }
};
